// =============================================
// 3D KEYPAD INTERACTIONS
// Sound effects and key press animations
// =============================================

(function() {
    // Only run if keypad exists and not on mobile
    const keypad = document.querySelector('.keypad');
    if (!keypad || window.innerWidth <= 900) return;

    // Audio for key clicks
    const clickAudio = new Audio('https://cdn.freesound.org/previews/378/378085_6260145-lq.mp3');
    clickAudio.volume = 0.3;

    // Key configurations
    const keys = {
        one: {
            element: document.querySelector('#key-one'),
            key: 'g', // G for GTM
        },
        two: {
            element: document.querySelector('#key-two'),
            key: '0', // 0 for 0→1
        },
        three: {
            element: document.querySelector('#key-three'),
            key: 'Enter', // Enter for grow/submit
        }
    };

    // Add click sound to keys
    Object.values(keys).forEach(keyConfig => {
        if (keyConfig.element) {
            keyConfig.element.addEventListener('pointerdown', () => {
                clickAudio.currentTime = 0;
                clickAudio.play().catch(() => {}); // Ignore autoplay errors
            });

            // Optional: Click key three to proceed
            if (keyConfig.element.id === 'key-three') {
                keyConfig.element.addEventListener('click', () => {
                    const nameInput = document.getElementById('userName');
                    if (nameInput && nameInput.value.trim()) {
                        goToSection(1);
                    } else {
                        nameInput.focus();
                        nameInput.classList.add('shake');
                        setTimeout(() => nameInput.classList.remove('shake'), 500);
                    }
                });
            }
        }
    });

    // Keyboard bindings
    window.addEventListener('keydown', (event) => {
        Object.values(keys).forEach(keyConfig => {
            if (keyConfig.element && event.key.toLowerCase() === keyConfig.key.toLowerCase()) {
                keyConfig.element.dataset.pressed = 'true';
                clickAudio.currentTime = 0;
                clickAudio.play().catch(() => {});
            }
        });
    });

    window.addEventListener('keyup', (event) => {
        Object.values(keys).forEach(keyConfig => {
            if (keyConfig.element && event.key.toLowerCase() === keyConfig.key.toLowerCase()) {
                keyConfig.element.dataset.pressed = 'false';
            }
        });
    });

    // Show keypad after load
    setTimeout(() => {
        keypad.style.opacity = '1';
    }, 500);

})();

// Add shake animation CSS
const shakeStyle = document.createElement('style');
shakeStyle.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        20%, 60% { transform: translateX(-5px); }
        40%, 80% { transform: translateX(5px); }
    }
    .shake {
        animation: shake 0.5s ease;
        border-color: #ff5757 !important;
    }
`;
document.head.appendChild(shakeStyle);
